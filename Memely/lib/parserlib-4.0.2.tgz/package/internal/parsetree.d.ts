import { ParseTree } from "./types.js";
export declare class InternalParseTree<NT> implements ParseTree<NT> {
    readonly name: NT;
    private readonly nonterminalName;
    readonly start: number;
    readonly text: string;
    readonly allChildren: ReadonlyArray<ParseTree<NT>>;
    readonly isSkipped: boolean;
    constructor(name: NT, nonterminalName: string, start: number, text: string, allChildren: ReadonlyArray<ParseTree<NT>>, isSkipped: boolean);
    private checkRep;
    get end(): number;
    private _childrenByName?;
    childrenByName(name: NT): ReadonlyArray<ParseTree<NT>>;
    private _children?;
    get children(): ReadonlyArray<ParseTree<NT>>;
    concat(that: InternalParseTree<NT>): InternalParseTree<NT>;
    toString(): string;
}
