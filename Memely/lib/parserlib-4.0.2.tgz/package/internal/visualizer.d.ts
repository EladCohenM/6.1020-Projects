import { ParseTree, NonterminalEnum } from "./types.js";
/**
 * Visualizes a parse tree using a URL that can be pasted into your web browser.
 * @param parseTree tree to visualize
 * @param <NT> the enumeration of symbols in the parse tree's grammar
 * @return url that shows a visualization of the parse tree
 */
export declare function visualizeAsUrl<NT>(parseTree: ParseTree<NT>, nonterminals: NonterminalEnum): string;
