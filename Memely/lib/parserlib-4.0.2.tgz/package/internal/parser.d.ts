import { Parser, ParseTree } from './types.js';
import { InternalParseTree } from './parsetree.js';
/**
 * Defines a term in a grammar, providing a parse method that parses that particular kind of term.
 */
export interface GrammarTerm<NT> {
    /**
     * Given a string s and a position pos within the string, this method will attempt to parse
     * this particular GrammarTerm<NT> from the string. If the GrammarTerm<NT> is successfully parsed,
     * the ParseResult<NT> will include a {@link InternalParseTree<NT>} for the term and the position in the string where
     * that term ends. This means that {@link ParseResult<NT>}.pos is between pos and s.length.
     *
     * If the GrammarTerm<NT> is not parsed successfully, then the ParseResult<NT> will
     * indicate that (see definition of {@link ParseResult<NT>}).
     *
     *
     * @param s string to parse
     * @param pos should be a valid position in the string s.
     * @param definitions should contain a definition of *all* the nonterminals in the grammar.
     * @return result of matching this grammar term against s starting from position pos
     * @throws UnableToParseException if a parse failure occurs that can't be fixed by backtracking
     */
    parse(s: string, pos: number, definitions: GrammarDefinitions<NT>, state: ParserState<NT>): ParseResult<NT>;
    /**
     * @return grammar expression for this term
     */
    toString(): string;
}
/**
* A particular use of the GrammarConstruct class overrides this method to actually return
* a map of GrammarTerm<NT>s.
* Requires every key to be a lower-case nonterminal.
* @return Map of nonterminals and their corresponding grammar terms. All elements in the NT Enum must
* be represented in this map.
* @throws UnableToParseException if the nonterminals in the grammar are not in 1-1 correspondence with the symbols in NT
*/
export type GrammarDefinitions<NT> = Map<NT, GrammarTerm<NT>>;
export declare function nt<NT>(nonterminal: NT, nonterminalName: string): GrammarTerm<NT>;
export declare function regex<NT>(regexSource: string): GrammarTerm<NT>;
export declare function str<NT>(str: string): GrammarTerm<NT>;
export declare function cat<NT>(...terms: GrammarTerm<NT>[]): GrammarTerm<NT>;
/**
 * @param choices must be nonempty
 */
export declare function or<NT>(...choices: GrammarTerm<NT>[]): GrammarTerm<NT>;
export interface HowMany {
    tooLow(n: number): boolean;
    tooHigh(n: number): boolean;
    toString(): string;
}
export declare class AtLeast implements HowMany {
    private readonly min;
    constructor(min: number);
    tooLow(n: number): boolean;
    tooHigh(n: number): boolean;
    toString(): string;
}
export declare class Between implements HowMany {
    private readonly min;
    private readonly max;
    constructor(min: number, max: number);
    tooLow(n: number): boolean;
    tooHigh(n: number): boolean;
    toString(): string;
}
export declare const ZERO_OR_MORE: HowMany;
export declare const ONE_OR_MORE: HowMany;
export declare const ZERO_OR_ONE: HowMany;
export declare function repeat<NT>(gt: GrammarTerm<NT>, howmany: HowMany): GrammarTerm<NT>;
export declare function star<NT>(gt: GrammarTerm<NT>): GrammarTerm<NT>;
export declare function plus<NT>(gt: GrammarTerm<NT>): GrammarTerm<NT>;
export declare function option<NT>(gt: GrammarTerm<NT>): GrammarTerm<NT>;
export declare function skip<NT>(nonterminal: GrammarTerm<NT>): GrammarTerm<NT>;
export declare function failfast<NT>(gt: GrammarTerm<NT>): GrammarTerm<NT>;
export declare class InternalParser<NT> implements Parser<NT> {
    private readonly definitions;
    private readonly start;
    private nonterminalToString;
    constructor(definitions: GrammarDefinitions<NT>, start: GrammarTerm<NT>, nonterminalToString: (nt: NT) => string);
    private checkRep;
    parse(textToParse: string): ParseTree<NT>;
    toString(): string;
}
type ParseResult<NT> = SuccessfulParse<NT> | FailedParse<NT>;
export interface BaseResult<NT> {
    readonly failed: boolean;
    readonly pos: number;
}
export declare class SuccessfulParse<NT> implements BaseResult<NT> {
    readonly pos: number;
    readonly tree: InternalParseTree<NT>;
    readonly lastFailure?: FailedParse<NT> | undefined;
    readonly failed: false;
    constructor(pos: number, tree: InternalParseTree<NT>, lastFailure?: FailedParse<NT> | undefined);
    replaceTree(tree: InternalParseTree<NT>): SuccessfulParse<NT>;
    mergeResult(that: SuccessfulParse<NT>): SuccessfulParse<NT>;
    /**
     * Keep track of a failing parse result that prevented this tree from matching more of the input string.
     * This deeper failure is usually more informative to the user, so we'll display it in the error message.
     * @param newLastFailure a failing ParseResult<NT> that stopped this tree's parse (but didn't prevent this from succeeding)
     * @return a new ParseResult<NT> identical to this one but with lastFailure added to it
     */
    addLastFailure(newLastFailure: FailedParse<NT>): SuccessfulParse<NT>;
}
export declare class FailedParse<NT> implements BaseResult<NT> {
    readonly pos: number;
    readonly nonterminalName: string;
    readonly expectedText: string;
    readonly failed: true;
    constructor(pos: number, nonterminalName: string, expectedText: string);
}
export declare class ParserState<NT> {
    private readonly nonterminalToString;
    private readonly stack;
    private readonly first;
    private skipDepth;
    constructor(nonterminalToString: (nt: NT) => string);
    enter(pos: number, nonterminal: NT): void;
    leave(nonterminal: NT): void;
    enterSkip(): void;
    leaveSkip(): void;
    isEmpty(): boolean;
    get currentNonterminal(): NT | undefined;
    get currentNonterminalName(): string | undefined;
    makeParseTree(pos: number, text?: string, children?: ParseTree<NT>[]): InternalParseTree<NT>;
    makeSuccessfulParse(fromPos: number, toPos: number, text?: string, children?: ParseTree<NT>[]): SuccessfulParse<NT>;
    makeFailedParse(atPos: number, expectedText: string): FailedParse<NT>;
}
export {};
