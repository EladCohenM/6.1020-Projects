/**
 * Type of the runtime object for an enumeration.
 */
export type NonterminalEnum = {
    [enumSymbol: string]: string | number;
};
/**
 * A Parser is an immutable object that is able to take a sequence of characters and return a parse tree according
 * to some grammar.
 *
 * Parsers are constructed by calling compile() with a grammar, which might be stored in a
 * string, in a file, or read from a stream.
 *
 * Once constructed, a Parser object is used by calling parse() on a string.  Its result is a ParseTree showing how that string matches the grammar.
 *
 * The type parameter <code>NT</code> should be an Enum type with the same (case-insensitive) names as
 * the nonterminals in the grammar. This allows nonterminals to be referred to by your code with static checking
 * and type safety. For example, if your grammar is:
 * ```
 * const sumGrammar = "expression ::= constant '+' constant ;  constant ::= [0-9]+ ;"
 * ```
 * then you should create a nonterminal enum like this:
 * ```
 * enum SumGrammar { Expression, Constant };
 * ```
 * and then use:
 * ```
 * compile(sumGrammar, SumGrammar, SumGrammar.Expression)
 * ```
 * to compile it into a parser.
 *
 * The grammar of a grammar is as follows.
 * ```text
 *   @skip whitespaceAndComments {
 *     grammar ::= ( production | skipBlock )+
 *     production ::= nonterminal '::=' union ';'
 *     skipBlock ::= '@skip' nonterminal '{' production* '}'
 *     union :: = concatenation ('|' concatenation)*
 *     concatenation ::= repetition*
 *     repetition ::= unit repeatOperator?
 *     unit ::= nonterminal | terminal | '(' union ')'
 *   }
 *   nonterminal ::= [a-zA-Z_][a-zA-Z_0-9]*
 *   terminal ::= quotedString | characterSet | anyChar | characterClass
 *   quotedString ::= "'" ([^'\r\n\\] | '\\' . )* "'"
 *                  | '"' ([^"\r\n\\] | '\\' . )* '"'
 *   characterSet ::= '[' ([^\]\r\n\\] | '\\' . )+ ']'
 *   anyChar ::= '.'
 *   repeatOperator ::= [*+?] | '{' ( number | range | upperBound | lowerBound ) '}'
 *   number ::= [0-9]+
 *   range ::= number ',' number
 *   upperBound ::= ',' number
 *   lowerBound ::= number ','
 *   characterClass ::= '\\' [dsw]     // e.g. \d, \s, \w
 *   whitespaceAndComments ::= (whitespace | oneLineComment | blockComment)*
 *   whitespace ::= [ \t\r\n]
 *   oneLineComment ::= '//' [^\r\n]* [\r\n]+
 *   blockComment ::= '/*' [^*]* '*' ([^/]* '*')* '/'
 * ```
 *
 * @param <NT> a Typescript Enum with one symbol for each nonterminal used in the grammar,
 *        matching the nonterminals when compared case-insensitively (so ROOT and Root and root are the same).
 *
 */
export interface Parser<NT> {
    /**
     * Parses a string based on the grammar internally represented by the parser.
     * @param str string to parse
     * @return {@link ParseTree} representing a successful parse of the string
     * @throws ParseError if string cannot be parsed, describing approximately where the parsing error occurred
     */
    parse(str: string): ParseTree<NT>;
}
/**
 * Represents an immutable parse tree.
 *
 * Each node represents the application of a production rule from the grammar, `name ::= expr`.
 *
 * The node's name() is the nonterminal on the left side of the production rule,
 * and the node's children() are the production rules that were matched for each nonterminal
 * used in the righthand side (expr).
 *
 * A node also has text() representing the substring matched by this node's subtree,
 * and start()/end() indicating where that substring is relative to the entire string parsed.
 *
 * If the grammar used `@skip` to skip over some nonterminals automatically, then the skipped subtrees do not appear
 * among this node's children(), but can be found by using allChildren() or childrenByName().
 *
 * @param <NT> a Typescript Enum with one symbol for each nonterminal used in the grammar,
 *        matching the nonterminals when compared case-insensitively (so ROOT and Root and root are the same).
 *
 */
export interface ParseTree<NT> {
    /**
     * Get this node's name.
     * @return the nonterminal corresponding to this node in the parse tree.
     */
    readonly name: NT;
    /**
     * Get this node's children.
     * @return an immutable array of the children of this node, in order, excluding @skipped subtrees
     */
    readonly children: ReadonlyArray<ParseTree<NT>>;
    /**
     * Get this subtree's text.
     * @return the substring of the entire parsed string that this subtree matched
     */
    readonly text: string;
    /**
     * Get the offset where this subtree starts in the entire parsed string.
     * @return the offset [0,...length-1] in the entire parsed string where this subtree started to match
     */
    readonly start: number;
    /**
     * Get the offset where this subtree ends in the entire parsed string.
     * @return the offset [0,...length-1] in the entire parsed string where this subtree ends
     */
    readonly end: number;
    /**
     * Get the children that correspond to a particular production rule.
     * @param name name of the nonterminal corresponding to the desired production rule.
     * @return an immutable array of the children that represent matches of name's production rule, in order.
     */
    childrenByName(name: NT): ReadonlyArray<ParseTree<NT>>;
    /**
     * Get all of this node's children, including @skip rules.
     * @return an immutable array of all the children of this node, in order, including @skipped subtrees
     */
    readonly allChildren: ReadonlyArray<ParseTree<NT>>;
    /**
     * Test if this node is in a subtree that was @skipped.
     * @return true iff this node is part of a subtree that was automatically skipped over by
     * a @skip rule.
     */
    readonly isSkipped: boolean;
}
/**
 * Exception thrown when a sequence of characters doesn't match a grammar
 */
export declare class ParseError extends Error {
    constructor(message: string);
}
export declare class InternalParseError extends ParseError {
    readonly nonterminalName: string;
    readonly expectedText: string;
    readonly textBeingParsed: string;
    readonly pos: number;
    constructor(message: string, nonterminalName: string, expectedText: string, textBeingParsed: string, pos: number);
}
export declare class GrammarError extends ParseError {
    constructor(message: string, e?: InternalParseError);
}
