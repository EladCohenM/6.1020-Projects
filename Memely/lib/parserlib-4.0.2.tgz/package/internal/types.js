import { makeErrorMessage } from './display.js';
/**
 * Exception thrown when a sequence of characters doesn't match a grammar
 */
export class ParseError extends Error {
    constructor(message) {
        super(message);
    }
}
export class InternalParseError extends ParseError {
    nonterminalName;
    expectedText;
    textBeingParsed;
    pos;
    constructor(message, nonterminalName, expectedText, textBeingParsed, pos) {
        super(makeErrorMessage(message, nonterminalName, expectedText, textBeingParsed, pos, "string being parsed"));
        this.nonterminalName = nonterminalName;
        this.expectedText = expectedText;
        this.textBeingParsed = textBeingParsed;
        this.pos = pos;
    }
}
export class GrammarError extends ParseError {
    constructor(message, e) {
        super(e ? makeErrorMessage(message, e.nonterminalName, e.expectedText, e.textBeingParsed, e.pos, "grammar")
            : message);
    }
}
//# sourceMappingURL=types.js.map