export const VERSION = "4.0.1";
export { ParseError } from './internal/types.js';
export { compile } from './internal/compiler.js';
export { visualizeAsUrl } from './internal/visualizer.js';
//# sourceMappingURL=parserlib.js.map