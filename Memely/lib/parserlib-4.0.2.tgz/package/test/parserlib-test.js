import 'mocha';
import assert from 'node:assert';
import { ParseError, compile } from '../parserlib.js';
import { GrammarError } from '../internal/types.js';
describe('parser', () => {
    it('should handle simple grammar no operators', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const parser = compile("num::='1';term::=num;exp::=term;", NT, NT.exp);
        //console.log(parser);
        const tree = parser.parse('1');
        assert.equal(tree.name, NT.exp);
        assert.equal(tree.text, '1');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        assert.equal(tree.children[0].name, NT.term);
        assert.equal(tree.children[0].text, '1');
        assert.equal(tree.children[0].start, 0);
        assert.equal(tree.children[0].end, 1);
        assert.deepEqual(tree.childrenByName(NT.term), tree.children);
        assert.deepEqual(tree.childrenByName(NT.num), []);
    });
    it('should handle simple grammar with operators', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["exp"] = 1] = "exp";
        })(NT || (NT = {}));
        ;
        const parser = compile("\nnum::='1'|'2';exp::=num '&' num;", NT, NT.exp);
        //console.log(parser);
        const tree = parser.parse('1&2');
        assert.equal(tree.name, NT.exp);
        assert.equal(tree.text, '1&2');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 3);
        assert.equal(tree.children.length, 2);
        assert.equal(tree.children[0].text, '1');
        assert.equal(tree.children[0].start, 0);
        assert.equal(tree.children[0].end, 1);
        assert.equal(tree.children[1].text, '2');
        assert.equal(tree.children[1].start, 2);
        assert.equal(tree.children[1].end, 3);
        assert.deepEqual(tree.childrenByName(NT.num), tree.children);
    });
    it('should handle arithmetic grammar', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const parser = compile(`
num\t::= [0-9] ;
term\t::= num '&' term
          |  num;
exp\t::= term ( '+' term ) *;
`, NT, NT.exp);
        //console.log(parser);
        const tree = parser.parse('9+2&4');
        assert.equal(tree.name, NT.exp);
        assert.equal(tree.text, '9+2&4');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 5);
        assert.equal(tree.children.length, 2);
        assert.equal(tree.children[0].text, '9');
        assert.equal(tree.children[0].start, 0);
        assert.equal(tree.children[0].end, 1);
        assert.equal(tree.children[1].text, '2&4');
        assert.equal(tree.children[1].start, 2);
        assert.equal(tree.children[1].end, 5);
        assert.deepEqual(tree.childrenByName(NT.term), tree.children);
        const subexpr = tree.children[1];
        assert.equal(subexpr.children.length, 2);
        assert.equal(subexpr.childrenByName(NT.num)[0].text, '2');
        assert.equal(subexpr.childrenByName(NT.num)[0].start, 2);
        assert.equal(subexpr.childrenByName(NT.num)[0].end, 3);
        assert.equal(subexpr.childrenByName(NT.term)[0].text, '4');
        assert.equal(subexpr.childrenByName(NT.term)[0].start, 4);
        assert.equal(subexpr.childrenByName(NT.term)[0].end, 5);
    });
    it('should handle comments', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = "/* This is a block comment */\n" +
            "num ::= [0-9]; // this is a line comment\n" +
            "/* another * * * comment ***/\n" +
            "exp ::= num;\n term ::= num;";
        const parser = compile(grammar, NT, NT.exp);
        const tree = parser.parse('5');
        assert.equal(tree.name, NT.exp);
        assert.equal(tree.text, '5');
    });
    it('should handle @skip', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["whitespace"] = 1] = "whitespace";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = "num   ::= '-'? [0-9]+;\n" +
            "whitespace ::= [ \\t\\r\\n];\n" +
            "@skip whitespace {exp::= num ( '+' num )*;}\n";
        const parser = compile(grammar, NT, NT.exp);
        // console.error(parser.toString());
        const input = "  55  +0  \t + -8 \r + \n 10  ";
        const tree = parser.parse(input);
        assert.equal(tree.name, NT.exp);
        assert.equal(tree.text, input);
        // console.error(tree);
        assert.equal(tree.childrenByName(NT.whitespace).length, 17);
        assert.equal(tree.allChildren.length, 21);
        assert.deepEqual(tree.children, tree.childrenByName(NT.num));
        assert.deepEqual(['55', '0', '-8', '10'], tree.children.map(child => child.text));
    });
    it('should handle character classes', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
        })(NT || (NT = {}));
        ;
        assert.equal(compile("s ::= .*;", NT, NT.s).parse("anything").text, "anything");
        assert.equal(compile("s ::= \\d+ \\s+ \\w+;", NT, NT.s).parse("9320 \r\t\n foobar").text, "9320 \r\t\n foobar");
    });
    it('should handle escape codes', () => {
        let NT_BRACKET;
        (function (NT_BRACKET) {
            NT_BRACKET[NT_BRACKET["bracket"] = 0] = "bracket";
        })(NT_BRACKET || (NT_BRACKET = {}));
        ;
        let NT_QUOTE;
        (function (NT_QUOTE) {
            NT_QUOTE[NT_QUOTE["quote"] = 0] = "quote";
        })(NT_QUOTE || (NT_QUOTE = {}));
        ;
        let NT_WS;
        (function (NT_WS) {
            NT_WS[NT_WS["ws"] = 0] = "ws";
        })(NT_WS || (NT_WS = {}));
        ;
        let NT_SLASH;
        (function (NT_SLASH) {
            NT_SLASH[NT_SLASH["slash"] = 0] = "slash";
        })(NT_SLASH || (NT_SLASH = {}));
        ;
        assert.equal(compile("bracket ::= [\\]];", NT_BRACKET, NT_BRACKET.bracket).parse("]").text, "]");
        assert.equal(compile("quote ::= '\\'';", NT_QUOTE, NT_QUOTE.quote).parse("'").text, "'");
        assert.equal(compile("quote ::= \"\\\"\";", NT_QUOTE, NT_QUOTE.quote).parse("\"").text, "\"");
        assert.equal(compile("ws ::= [\\t\\r\\n]+;", NT_WS, NT_WS.ws).parse("\t\r\n").text, "\t\r\n");
        assert.equal(compile("ws ::= \"\\t\\r\\n\";", NT_WS, NT_WS.ws).parse("\t\r\n").text, "\t\r\n");
        assert.equal(compile("ws ::= '\\t\\r\\n';", NT_WS, NT_WS.ws).parse("\t\r\n").text, "\t\r\n");
        assert.equal(compile("slash ::= \" \\\\ \";", NT_SLASH, NT_SLASH.slash).parse(" \\ ").text, " \\ ");
        assert.equal(compile("slash ::= ' \\\\ ';", NT_SLASH, NT_SLASH.slash).parse(" \\ ").text, " \\ ");
        assert.equal(compile("slash ::= [\\\\];", NT_SLASH, NT_SLASH.slash).parse("\\").text, "\\");
    });
    it('should handle numbers', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
        })(NT || (NT = {}));
        ;
        const grammar = "num::=[1-9][0-9]* | '0';";
        const parser = compile(grammar, NT, NT.num);
        const tree = parser.parse("10");
        assert.equal(tree.name, NT.num);
        assert.equal(tree.text, "10");
        assert.equal(parser.parse("55").text, "55");
        assert.equal(parser.parse("5").text, "5");
        assert.equal(parser.parse("0").text, "0");
    });
    it('should handle Lec17a example', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
            NT[NT["y"] = 1] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::= y?;" +
            "y ::= [abc];";
        const parser = compile(grammar, NT, NT.x);
        const tree = parser.parse("a");
        const stringRepresentation = tree.toString();
        //console.log(stringRepresentation);
        assert(stringRepresentation.toLowerCase().includes("x"));
        assert(stringRepresentation.toLowerCase().includes("y"));
        assert(stringRepresentation.includes("a"));
        assert.equal(tree.name, NT.x);
        assert.equal(tree.childrenByName(NT.y)[0].text, "a");
    });
    it('should handle Lec17b example', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
            NT[NT["y"] = 1] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::= y+;" +
            "y ::= [^b];";
        const parser = compile(grammar, NT, NT.x);
        const tree = parser.parse("always");
        assert.equal(tree.name, NT.x);
        assert.equal(tree.childrenByName(NT.y)[0].text, "a");
    });
    it('should handle Lec17c example', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
            NT[NT["y"] = 1] = "y";
            NT[NT["z"] = 2] = "z";
            NT[NT["a"] = 3] = "a";
            NT[NT["b"] = 4] = "b";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::=  (y z | a b)*;" +
            "y ::= [abc];" +
            "z ::= [def];" +
            "a ::= [ghi];" +
            "b ::= [jkl];";
        const parser = compile(grammar, NT, NT.x);
        const tree = parser.parse("adadadgkgk");
        assert.equal(tree.name, NT.x);
        assert.equal(tree.childrenByName(NT.y)[0].text, "a");
    });
    it('should handle Lec17d example', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["a"] = 1] = "a";
            NT[NT["b"] = 2] = "b";
            NT[NT["c"] = 3] = "c";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= 'a'+ 'b'* 'c'?;";
        const parser = compile(grammar, NT, NT.root);
        const tree = parser.parse("abbbbbc");
        assert.equal(tree.name, NT.root);
    });
    it('should handle Lec17e example', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["integer"] = 1] = "integer";
        })(NT || (NT = {}));
        ;
        const grammar = "root    ::= integer ('-' integer)+;" +
            "integer ::= [0-9]+;";
        const parser = compile(grammar, NT, NT.root);
        const tree = parser.parse("123-45-67");
        assert.equal(tree.name, NT.root);
    });
    it('should handle Lec17f example (and case insensitivity)', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["a"] = 1] = "a";
            NT[NT["b"] = 2] = "b";
        })(NT || (NT = {}));
        ;
        const grammar = "rOoT   ::= (A B)+;" + //testing case insensitivity.
            "A      ::= [Aa];" +
            "B      ::= [Bb];";
        const parser = compile(grammar, NT, NT.root);
        const tree = parser.parse("Ab");
        assert.equal(tree.name, NT.root);
    });
    it('should handle Lec17g example', () => {
        let NT;
        (function (NT) {
            NT[NT["url"] = 0] = "url";
        })(NT || (NT = {}));
        ;
        const grammar = "url ::= 'http://' [a-z]+ '.' [a-z]+  '/'?;";
        const parser = compile(grammar, NT, NT.url);
        const tree = parser.parse("http://google.com");
        assert.equal(tree.name, NT.url);
    });
    it('should handle Lec17h example', () => {
        let NT;
        (function (NT) {
            NT[NT["url"] = 0] = "url";
            NT[NT["hostname"] = 1] = "hostname";
            NT[NT["word"] = 2] = "word";
        })(NT || (NT = {}));
        ;
        const grammar = "url ::= 'http://' hostname '/'?; \n" +
            "hostname ::= word '.' word; \n" +
            "word ::= [a-z]+; \n";
        const parser = compile(grammar, NT, NT.url);
        const tree = parser.parse("http://google.com/");
        assert.equal(tree.name, NT.url);
    });
    it('should handle Lec17i example', () => {
        let NT;
        (function (NT) {
            NT[NT["url"] = 0] = "url";
            NT[NT["hostname"] = 1] = "hostname";
            NT[NT["word"] = 2] = "word";
            NT[NT["port"] = 3] = "port";
        })(NT || (NT = {}));
        ;
        const grammar = "url ::= 'http://' hostname (':' port)? '/';" +
            "hostname ::= word '.' hostname | word '.' word;" +
            "port ::= [0-9]+;" +
            "word ::= [a-z]+;";
        const parser = compile(grammar, NT, NT.url);
        const tree = parser.parse("http://mit.google.com:123/");
        assert.equal(tree.name, NT.url);
    });
    function countNodes(tree) {
        let n = 1;
        for (const child of tree.children) {
            n += countNodes(child);
        }
        return n;
    }
    function countAllNodes(tree) {
        let n = 1;
        for (const child of tree.allChildren) {
            n += countAllNodes(child);
        }
        return n;
    }
    it('should handle Lec17j example', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["sum"] = 1] = "sum";
            NT[NT["whitespace"] = 2] = "whitespace";
            NT[NT["primitive"] = 3] = "primitive";
            NT[NT["number"] = 4] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= sum; "
            + "@skip whitespace{"
            + "sum ::= primitive ('+' primitive)*;"
            + "primitive ::= number | '(' sum ')';"
            + "} "
            + "whitespace ::= [ \\t\\r\\n]+;"
            + "number ::= [0-9]+;";
        const parser = compile(grammar, NT, NT.root);
        const input = "1 + 2 + \n 3";
        const tree = parser.parse(input);
        assert.equal(tree.name, NT.root);
        assert.equal(tree.text, input);
        assert.equal(countNodes(tree), 8);
        assert.equal(countAllNodes(tree), 12);
    });
    it('should handle Lec17k example', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["sum"] = 1] = "sum";
            NT[NT["whitespace"] = 2] = "whitespace";
            NT[NT["primitive"] = 3] = "primitive";
            NT[NT["number"] = 4] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= sum; "
            + "@skip whitespace{"
            + "sum ::= primitive | primitive '+' sum;"
            + "primitive ::= number | '(' sum ')';"
            + "} "
            + "whitespace ::= [ \\t\\r\\n]+;"
            + "number ::= [0-9]+;";
        const parser = compile(grammar, NT, NT.root);
        const input = "1 + 2 + \n 3 + 4 + 5 + (6+7) + 8";
        const tree = parser.parse(input);
        const stringRepresentation = tree.toString();
        //console.log(stringRepresentation);
        for (const token of ['1', '4', '6', '8', '+', '(', ')', 'PRIMITIVE', 'NUMBER', 'WHITESPACE', 'SUM', 'ROOT']) {
            assert(stringRepresentation.toLowerCase().includes(token.toLowerCase()));
        }
        assert.equal(tree.name, NT.root);
        assert.equal(tree.text, input);
        assert.equal(countNodes(tree), 27);
        assert.equal(countAllNodes(tree), 39);
    });
    it('should handle ranges', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
            NT[NT["y"] = 1] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::= 'a'{3} | 'b'{,3} | 'c'{2,4} | 'd'{5,};"
            + "y ::= 'e'{,0};";
        const parserX = compile(grammar, NT, NT.x);
        const parserY = compile(grammar, NT, NT.y);
        parserX.parse("aaa");
        assert.throws(() => parserX.parse("aa"), ParseError);
        assert.throws(() => parserX.parse("aaaa"), ParseError);
        parserX.parse("");
        parserX.parse("b");
        parserX.parse("bb");
        parserX.parse("bbb");
        assert.throws(() => parserX.parse("bbbb"), ParseError);
        parserX.parse("cc");
        parserX.parse("ccc");
        parserX.parse("ccc");
        assert.throws(() => parserX.parse("c"), ParseError);
        assert.throws(() => parserX.parse("cccccc"), ParseError);
        parserX.parse("ddddd");
        parserX.parse("dddddd");
        assert.throws(() => parserX.parse("dddd"), ParseError);
        parserY.parse("");
        assert.throws(() => parserY.parse("e"), ParseError);
    });
    it('should match newlines with dot too', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
            NT[NT["x"] = 1] = "x";
            NT[NT["y"] = 2] = "y";
        })(NT || (NT = {}));
        ;
        const parser = compile("s ::= 'x'.'y';", NT, NT.s);
        parser.parse("x y");
        parser.parse("x\ny");
        assert.throws(() => parser.parse("x\n y"), ParseError);
    });
    it('should print parse tree including terminals (string literals)', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
            NT[NT["t"] = 1] = "t";
        })(NT || (NT = {}));
        ;
        const grammar = "s ::= 'abra' t 'cadbra' t 'elbra'; t ::= 'x'*;";
        const parser = compile(grammar, NT, NT.s);
        const input = "abracadbraelbra";
        const tree = parser.parse(input);
        const stringRepresentation = tree.toString();
        //console.log(stringRepresentation);
        assert(stringRepresentation.includes("abra"));
        assert(stringRepresentation.includes("cadbra"));
        assert(stringRepresentation.includes("elbra"));
    });
    it('should handle empty productions', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::= | 'x' x;";
        const parser = compile(grammar, NT, NT.x);
        assert.equal(parser.parse("").text, "");
        assert.equal(parser.parse("xxxx").text, "xxxx");
        assert.throws(() => parser.parse("xxy"), ParseError);
    });
    it('should handle multiple productions for same nonterminal', () => {
        let NT;
        (function (NT) {
            NT[NT["y"] = 0] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "y ::= 'a' y ; y ::= ;";
        const parser = compile(grammar, NT, NT.y);
        assert.equal(parser.parse("").text, "");
        assert.equal(parser.parse("aaa").text, "aaa");
        assert.throws(() => parser.parse("ab"), ParseError);
    });
    it('should handle empty string literal', () => {
        let NT;
        (function (NT) {
            NT[NT["z"] = 0] = "z";
        })(NT || (NT = {}));
        ;
        const grammar = "z ::= 'ab' '' \"cd\" \"\" 'ef';";
        const parser = compile(grammar, NT, NT.z);
        assert.equal(parser.parse("abcdef").text, "abcdef");
        assert.throws(() => parser.parse("abc"), ParseError);
    });
    it('should handle unicode', () => {
        let NT;
        (function (NT) {
            NT[NT["nature"] = 0] = "nature";
        })(NT || (NT = {}));
        ;
        const bee = '\u{1F41D}';
        const flower = '\u{1F33B}';
        //console.log(bee, flower);
        const grammar = "nature ::= ( '" + bee + "' | '" + flower + "' )+;";
        const parser = compile(grammar, NT, NT.nature);
        const input = bee + bee + flower + bee + flower;
        assert.equal(parser.parse(input).text, input);
    });
    it('should have its own grammar as its toString', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = "\n" +
            "num\t::= [0-9] ;\n" +
            "term\t::= num '&' term\n" +
            "      |  num;\n" +
            "exp\t::= term ( '+' term ) *;\n";
        const parser = compile(grammar, NT, NT.exp);
        //console.error(parser.toString());
        const parser2 = compile(parser.toString(), NT, NT.exp);
        //console.error(parser2.toString());
        assert.equal(parser.toString(), parser2.toString());
        assert.deepEqual(parser.parse('1+2+3'), parser2.parse('1+2+3'));
    });
    it('should be able to print, reparse, print same way', () => {
        let NT;
        (function (NT) {
            NT[NT["w"] = 0] = "w";
            NT[NT["x"] = 1] = "x";
            NT[NT["y"] = 2] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "w ::= x*;" +
            "x ::= y?;" +
            "y ::= [abc]+;";
        const parser = compile(grammar, NT, NT.w);
        //console.error(parser.toString());
        const parser2 = compile(parser.toString(), NT, NT.w);
        assert.equal(parser.toString(), parser2.toString());
    });
    it('should allow nonterminal enum to be string enum', () => {
        let NT;
        (function (NT) {
            NT["root"] = "root";
        })(NT || (NT = {}));
        ;
        const grammar = "root::='0';";
        assert.equal(compile(grammar, NT, NT.root).parse("0").text, "0");
        assert.throws(() => compile(grammar, NT, NT.root).parse("nope"), (e) => {
            assert(e.message.toLowerCase().includes('root'));
            return true;
        });
    });
});
describe('error handling', () => {
    const displayParserErrors = false; // for debugging
    it('should report offsets and unexpected text', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = "num ::= '1' | '2' | '3';\n" +
            "term ::= num '&' term | num;\n" +
            "exp ::= term ('+' term)*;\n";
        const parser = compile(grammar, NT, NT.exp);
        assert.throws(() => parser.parse("1+2+&3"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('&'));
            assert(e.message.includes('offset 4'));
            return true;
        });
    });
    it('should detect left recursion', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = "\n" +
            "num ::= [0-9] ;\n" +
            "term ::= term '&' num\n" +
            "      |  num;\n" +
            "exp ::= term ( '+' term ) *;\n";
        const parser = compile(grammar, NT, NT.exp);
        assert.throws(() => parser.parse("0&0&0"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes('left recursion'));
            assert(e.message.includes('term'));
            return true;
        });
    });
    it('should report grammar error on correct line', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ;
        const grammar = 
        //"\n"+
        "num ::= [0-9] ;\n" + // first line is line 1.
            "term := num '&' term\n" + // error
            "      |  num;\n" +
            "exp ::= term ( '+' term ) *;\n";
        assert.throws(() => compile(grammar, NT, NT.exp), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes('::='));
            assert(e.message.includes('line 2'));
            assert(e.message.includes('column 6'));
            return true;
        });
    });
    it('should report missing closing quote when line ends', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["html"] = 1] = "html";
            NT[NT["italic"] = 2] = "italic";
            NT[NT["normal"] = 3] = "normal";
            NT[NT["text"] = 4] = "text";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= html; \n" +
            "html ::= (italic | normal)*;\n" +
            "italic ::= '<i>' html </i>'; \n" +
            "normal ::= text; \n" +
            "text ::= [a-z]";
        assert.throws(() => compile(grammar, NT, NT.root), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes('</i>'));
            assert(e.message.includes('line 3'));
            assert(e.message.includes('column 23'));
            return true;
        });
    });
    it('should report unexpected char', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["html"] = 1] = "html";
            NT[NT["italic"] = 2] = "italic";
            NT[NT["normal"] = 3] = "normal";
            NT[NT["text"] = 4] = "text";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= html; \n" +
            "html ::= (italic | normal)*;\n" +
            "italic ::= '<i>' html '</i>'; \n" +
            "normal ::= text; \n" +
            "text ::= [a-z]*;";
        const parser = compile(grammar, NT, NT.root);
        parser.parse("hello<i>world</i>");
        assert.throws(() => parser.parse("hello<i>world!</i>"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('!'));
            //error message is not ideal, complaint should really be here:
            //assert(e.message.includes('offset 13'));
            return true;
        });
    });
    it('should report error on Lec17 example', () => {
        let NT;
        (function (NT) {
            NT[NT["x"] = 0] = "x";
            NT[NT["y"] = 1] = "y";
        })(NT || (NT = {}));
        ;
        const grammar = "x ::= y?;" +
            "y ::= [abc];";
        const parser = compile(grammar, NT, NT.x);
        assert.throws(() => parser.parse("az"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('z'));
            assert(e.message.includes('offset 1'));
            return true;
        });
    });
    it('should report error on another Lec17 example', () => {
        let NT;
        (function (NT) {
            NT[NT["root"] = 0] = "root";
            NT[NT["integer"] = 1] = "integer";
        })(NT || (NT = {}));
        ;
        const grammar = "root    ::= integer ('-' integer)+;" +
            "integer ::= [0-9]+;";
        const parser = compile(grammar, NT, NT.root);
        assert.throws(() => parser.parse("abbbbbc"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('abbb'));
            assert(e.message.includes('offset 0'));
            return true;
        });
    });
    it('should report missing semicolon as early as possible', () => {
        let NT;
        (function (NT) {
            NT[NT["primary"] = 0] = "primary";
            NT[NT["whitespace"] = 1] = "whitespace";
            NT[NT["number"] = 2] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "@skip whitespace {\n" +
            "   primary ::= '-' number;\n" +
            "}\n" +
            "number ::= [0-9]+;\n" +
            "whitespace ::= [ \\t\\r\\n]+;";
        assert.throws(() => compile(grammar.replace(";\nwhitespace", "\nwhitespace"), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes(';'));
            assert(e.message.includes('line 5'));
            // semicolons are still complained about too late, this should really be:
            //line 4 and column 18
            return true;
        });
        assert.throws(() => compile(grammar.replace(";\n}", "\n}"), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes(';'));
            assert(e.message.includes('line 3'));
            assert(e.message.includes('column 1'));
            return true;
        });
    });
    it('should complain about badly-formatted @skip', () => {
        let NT;
        (function (NT) {
            NT[NT["primary"] = 0] = "primary";
            NT[NT["whitespace"] = 1] = "whitespace";
            NT[NT["number"] = 2] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "@skip whitespace {\n" +
            "   primary ::= '-' number;\n" +
            "}\n" +
            "number ::= [0-9]+;\n" +
            "whitespace ::= [ \\t\\r\\n]+;";
        assert.throws(() => compile(grammar.replace("@skip whitespace", "@skip [ \\t\\r\\n]"), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.includes('[ '));
            assert(e.message.includes('line 1'));
            assert(e.message.includes('column 7'));
            return true;
        });
    });
    it('should report error on missing rule', () => {
        let NT;
        (function (NT) {
            NT[NT["primary"] = 0] = "primary";
            NT[NT["whitespace"] = 1] = "whitespace";
            NT[NT["number"] = 2] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "@skip whitespace { primary ::= number | '(' primary ')';  } number ::= [0-9]+; whitespace ::= [ \\t\\r\\n]+;";
        // grammar uses but doesn't define a nonterminal that is NOT mentioned in enum
        assert.throws(() => compile(grammar.replace("'(' primary", "'(' sum"), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.toLowerCase().includes('sum'));
            return true;
        });
        // grammar uses a nonterminal that's never defined in a production
        assert.throws(() => compile(grammar.replace("number ::= [0-9]+;", ""), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.toLowerCase().includes('number'));
            return true;
        });
        // starting nonterminal is never defined in a production
        assert.throws(() => compile(grammar.replace("primary ::= number | '(' primary ')';", ""), NT, NT.primary), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof GrammarError);
            assert(e.message.toLowerCase().includes('primary'));
            return true;
        });
    });
    it('should display special characters in error messages in a readable way', () => {
        let NT;
        (function (NT) {
            NT[NT["primary"] = 0] = "primary";
            NT[NT["whitespace"] = 1] = "whitespace";
            NT[NT["number"] = 2] = "number";
        })(NT || (NT = {}));
        ;
        const grammar = "primary ::= number | '(' primary ')';  number ::= [0-9]+; whitespace ::= [ \\t\\r\\n]+;";
        const whitespaceOnlyParser = compile(grammar, NT, NT.whitespace);
        const numberOnlyParser = compile(grammar, NT, NT.number);
        assert.throws(() => whitespaceOnlyParser.parse("abc"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('abc'));
            assert(e.message.includes('\\t'));
            assert(e.message.includes('\\r'));
            assert(e.message.includes('\\n'));
            return true;
        });
        assert.throws(() => numberOnlyParser.parse("\t \n"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.includes('[0-9]'));
            assert(e.message.includes('newline'));
            assert(e.message.includes('tab'));
            return true;
        });
    });
    it('should avoid localizing failure inside repetition', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
            NT[NT["ntx"] = 1] = "ntx";
            NT[NT["nty"] = 2] = "nty";
            NT[NT["ntz"] = 3] = "ntz";
        })(NT || (NT = {}));
        ;
        const grammar = "s ::= (ntx nty ntz)* ; ntx ::= 'x'; nty ::= 'y'; ntz ::= 'z';";
        const parser = compile(grammar, NT, NT.s);
        parser.parse("xyzxyzxyz"); // should parse ok
        assert.throws(() => parser.parse("xyzxyzxyw"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e instanceof ParseError);
            assert(e.message.toLowerCase().includes('ntz'));
            assert(e.message.includes('w'));
            return true;
        });
    });
    it('should avoid confusing escapes in error message', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
        })(NT || (NT = {}));
        ;
        const grammar = "s ::= '\\n' ;"; // S matches a newline character
        const parser = compile(grammar, NT, NT.s);
        parser.parse("\n"); // should parse ok
        assert.throws(() => parser.parse("\\n"), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e.message.includes('newline'));
            assert(e.message.includes('but saw \\n'));
            return true;
        });
    });
    it('should complain about case-insensitive name collisions in nonterminal enum', () => {
        let NT;
        (function (NT) {
            NT[NT["ROOT"] = 0] = "ROOT";
            NT[NT["Root"] = 1] = "Root";
        })(NT || (NT = {}));
        ;
        const grammar = "root ::= 'a' ;";
        assert.throws(() => compile(grammar, NT, NT.ROOT), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e.message.includes('ROOT'));
            assert(e.message.includes('Root'));
            return true;
        });
    });
    it('should detect nonterminals in the grammar but not the enumeration', () => {
        let NT;
        (function (NT) {
            NT[NT["num"] = 0] = "num";
            NT[NT["term"] = 1] = "term";
            NT[NT["exp"] = 2] = "exp";
        })(NT || (NT = {}));
        ; // but not "notused"
        const grammar = "num ::= [0-9]; term ::= num '&' term | num; exp ::= term; notused ::= 'notused';";
        assert.throws(() => compile(grammar, NT, NT.exp), (e) => {
            if (displayParserErrors)
                console.error(e);
            assert(e.message.includes('notused'));
            return true;
        });
    });
});
describe('parse tree', () => {
    it('should be immutable', () => {
        let NT;
        (function (NT) {
            NT[NT["s"] = 0] = "s";
            NT[NT["a"] = 1] = "a";
            NT[NT["b"] = 2] = "b";
        })(NT || (NT = {}));
        ;
        const grammar = "s ::= ( a b ) * ; a ::= 'a'; b ::= 'b' ;";
        const tree = compile(grammar, NT, NT.s).parse("ababab");
        assert.throws(() => tree.children.splice(0, 1), Error);
        assert.throws(() => tree.children[0] = tree.children[1], Error);
        assert.throws(() => tree.allChildren.splice(0, 1), Error);
        assert.throws(() => tree.allChildren[0] = tree.allChildren[1], Error);
        assert.throws(() => tree.childrenByName(NT.a).splice(0, 1), Error);
        assert.throws(() => tree.childrenByName(NT.a)[0] = tree.childrenByName(NT.a)[1], Error);
    });
});
//# sourceMappingURL=parserlib-test.js.map