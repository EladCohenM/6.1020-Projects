import 'mocha';
import assert from 'node:assert';
import { InternalParser, regex, nt, cat, str, or, repeat, ZERO_OR_MORE, ONE_OR_MORE, ZERO_OR_ONE } from '../internal/parser.js';
import { ParseError } from '../internal/types.js';
import { makeNonterminalConverters } from '../internal/compiler.js';
describe('nt and dot only', () => {
    it('should handle simple hand-constructed grammar', () => {
        // a ::= b
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, nt(NT.b, 'b'));
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('x');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'x');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        assert.equal(tree.childrenByName(NT.a).length, 0);
        assert.equal(tree.childrenByName(NT.b).length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
        assert.equal(child.childrenByName(NT.a).length, 0);
        assert.equal(child.childrenByName(NT.b).length, 0);
    });
    it('should match entire string and entire grammar', () => {
        // a ::= b
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, nt(NT.b, 'b'));
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        assert.throws(() => { parser.parse('xy'); }, ParseError);
        assert.throws(() => { parser.parse(''); }, ParseError);
    });
    it('should report missing nonterminal', () => {
        // a ::= b
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, nt(NT.b, 'b'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        assert.throws(() => { parser.parse('xy'); }, ParseError);
    });
    it('dot should match newlines too', () => {
        // a ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('\n');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, '\n');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 0);
    });
});
describe('cat', () => {
    it('concatenation with two operands', () => {
        // a ::= b .
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, cat(nt(NT.b, 'b'), regex('.')));
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('xy');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'xy');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 2);
        assert.equal(tree.children.length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
    });
    it('should match entire string and entire hand-constructed grammar', () => {
        // a ::= b .
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, cat(nt(NT.b, 'b'), regex('.')));
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        //assert.throws(()=>{ parser.parse('xyz'); }, ParseError);
        assert.throws(() => { parser.parse('x'); }, ParseError);
    });
    it('empty concatenation', () => {
        // a ::= 
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, cat());
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, '');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 0);
        assert.equal(tree.children.length, 0);
    });
});
describe('string literal', () => {
    it('should match string literals', () => {
        // a ::= b .
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, str('abc'));
        definitions.set(NT.b, str(''));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('abc');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'abc');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 3);
        assert.equal(tree.children.length, 0);
    });
    it('empty string', () => {
        // a ::= 
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, str('abc'));
        definitions.set(NT.b, str(''));
        const parser = new InternalParser(definitions, nt(NT.b, 'b'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('');
        assert.equal(tree.name, NT.b);
        assert.equal(tree.text, '');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 0);
        assert.equal(tree.children.length, 0);
    });
});
describe('or', () => {
    it('or with two operands', () => {
        // a ::= b .
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, or(nt(NT.b, 'b'), str('y')));
        definitions.set(NT.b, str('x'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('x');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'x');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
        const tree2 = parser.parse('y');
        assert.equal(tree2.name, NT.a);
        assert.equal(tree2.text, 'y');
        assert.equal(tree2.start, 0);
        assert.equal(tree2.end, 1);
        assert.equal(tree2.children.length, 0);
        assert.throws(() => { parser.parse('xy'); }, ParseError);
        assert.throws(() => { parser.parse('yx'); }, ParseError);
    });
    it('singleton or', () => {
        // a ::= 
        // b ::= .
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, or(nt(NT.b, 'b')));
        definitions.set(NT.b, regex('.'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('x');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'x');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
    });
});
describe('repeats', () => {
    it('repeat *', () => {
        // a ::= b*
        // b ::= 'x'
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, repeat(nt(NT.b, 'b'), ZERO_OR_MORE));
        definitions.set(NT.b, str('x'));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('x');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'x');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
        const tree2 = parser.parse('xxx');
        assert.equal(tree2.name, NT.a);
        assert.equal(tree2.text, 'xxx');
        assert.equal(tree2.start, 0);
        assert.equal(tree2.end, 3);
        assert.equal(tree2.children.length, 3);
        parser.parse('');
        parser.parse('xxxxxx');
        assert.throws(() => { parser.parse('xy'); }, ParseError);
        assert.throws(() => { parser.parse('yx'); }, ParseError);
    });
    it('repeat + and ?', () => {
        // a ::= b+
        // b ::= 'x' 'y'?
        let NT;
        (function (NT) {
            NT[NT["a"] = 0] = "a";
            NT[NT["b"] = 1] = "b";
        })(NT || (NT = {}));
        ;
        const definitions = new Map();
        definitions.set(NT.a, repeat(nt(NT.b, 'b'), ONE_OR_MORE));
        definitions.set(NT.b, cat(str('x'), repeat(str('y'), ZERO_OR_ONE)));
        const parser = new InternalParser(definitions, nt(NT.a, 'a'), makeNonterminalConverters(NT).nonterminalToString);
        const tree = parser.parse('x');
        assert.equal(tree.name, NT.a);
        assert.equal(tree.text, 'x');
        assert.equal(tree.start, 0);
        assert.equal(tree.end, 1);
        assert.equal(tree.children.length, 1);
        const child = tree.children[0];
        assert.equal(child.name, NT.b);
        assert.equal(child.text, 'x');
        assert.equal(child.start, 0);
        assert.equal(child.end, 1);
        assert.equal(child.children.length, 0);
        const tree2 = parser.parse('xxx');
        assert.equal(tree2.name, NT.a);
        assert.equal(tree2.text, 'xxx');
        assert.equal(tree2.start, 0);
        assert.equal(tree2.end, 3);
        assert.equal(tree2.children.length, 3);
        const tree3 = parser.parse('xyxxy');
        assert.equal(tree3.name, NT.a);
        assert.equal(tree3.text, 'xyxxy');
        assert.equal(tree3.start, 0);
        assert.equal(tree3.end, 5);
        assert.equal(tree3.children.length, 3);
        assert.throws(() => { parser.parse('xyy'); }, ParseError);
        assert.throws(() => { parser.parse(''); }, ParseError);
    });
});
//# sourceMappingURL=internal-test.js.map